<!DOCTYPE html>
<html>

<head>

<title>
Sport Court Booking System
</title>

<link
rel="stylesheet"
href="css/style.css">

</head>

<body>

<div class="container">

<div class="card">

<h1>
Sport Court Booking System
</h1>

<p>
Online Court Reservation Platform
</p>

<a href="register.php">
Register
</a>

&nbsp;&nbsp;

<a href="login.php">
Login
</a>

</div>

</div>

</body>
</html>