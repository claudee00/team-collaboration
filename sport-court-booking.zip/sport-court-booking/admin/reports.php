<?php

session_start();

if(!isset($_SESSION['user_id']))
{
    header("Location: ../login.php");
    exit();
}

if($_SESSION['role'] != 'admin')
{
    header("Location: ../login.php");
    exit();
}

?>

<!DOCTYPE html>
<html>

<head>

<title>Reports</title>

<link
rel="stylesheet"
href="../css/style.css">

</head>

<body>

<h1>Reports Module</h1>

<div class="menu">

<ul>

<li>
<a href="booking_report.php">
Booking Report
</a>
</li>

<li>
<a href="payment_report.php">
Payment Report
</a>
</li>

<li>
<a href="customer_report.php">
Customer Report
</a>
</li>

</ul>

</div>

<br>

<a href="dashboard.php">
Back to Dashboard
</a>

</body>
</html>