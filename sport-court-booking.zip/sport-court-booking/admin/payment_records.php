<?php

session_start();

include '../config/database.php';

if(!isset($_SESSION['user_id']))
{
    header("Location: ../login.php");
    exit();
}

if($_SESSION['role'] != 'admin')
{
    header("Location: ../login.php");
    exit();
}

$search = "";

if(isset($_GET['search']))
{
    $search = trim($_GET['search']);
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Payment Records</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>

<h2>Payment Records</h2>

<form method="GET">

<?php

$totalRevenueQuery =
mysqli_query(
$conn,
"SELECT
SUM(amount) AS total_revenue
FROM payments
WHERE payment_status='Paid'"
);

$totalRevenue =
mysqli_fetch_assoc(
$totalRevenueQuery
);

?>

<h3>

Total Revenue:
RM

<?php

echo number_format(
$totalRevenue['total_revenue'],
2
);

?>

</h3>

<input
type="text"
name="search"
placeholder="Search customer"

value="<?php echo $search; ?>">

<button type="submit">
Search
</button>

<a href="payment_records.php">
Reset
</a>

</form>

<br>

<table border="1">

<tr>

<th>Payment ID</th>
<th>Customer</th>
<th>Booking ID</th>
<th>Amount</th>
<th>Payment Method</th>
<th>Payment Status</th>
<th>Payment Date</th>

</tr>

<?php

$sql = "

SELECT

payments.*,
users.full_name

FROM payments

JOIN bookings
ON bookings.booking_id =
payments.booking_id

JOIN users
ON users.user_id =
bookings.user_id

";

if(!empty($search))
{
    $sql .= "
    WHERE users.full_name
    LIKE '%$search%'
    ";
}

$sql .= "
ORDER BY payments.payment_id DESC
";

$query = mysqli_query(
$conn,
$sql
);

while(
$row =
mysqli_fetch_assoc($query)
)
{
?>

<tr>

<td>
<?php echo $row['payment_id']; ?>
</td>

<td>
<?php echo $row['full_name']; ?>
</td>

<td>
<?php echo $row['booking_id']; ?>
</td>

<td>
RM <?php echo $row['amount']; ?>
</td>

<td>
<?php echo $row['payment_method']; ?>
</td>

<td>
<?php echo $row['payment_status']; ?>
</td>

<td>
<?php echo $row['payment_date']; ?>
</td>

</tr>

<?php
}
?>

</table>

<br>

<a href="dashboard.php">
Back to Dashboard
</a>

</body>
</html>