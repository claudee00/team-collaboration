<?php

session_start();

include '../config/database.php';

if($_SESSION['role'] != 'admin')
{
    header("Location: ../login.php");
    exit();
}

$message = "";

if(isset($_POST['add_court']))
{
    $court_name = $_POST['court_name'];
    $court_type = $_POST['court_type'];
    $description = $_POST['description'];
    $price_per_hour = $_POST['price_per_hour'];

    $insert = mysqli_query(
        $conn,
        "INSERT INTO courts
        (
            court_name,
            court_type,
            description,
            price_per_hour
        )
        VALUES
        (
            '$court_name',
            '$court_type',
            '$description',
            '$price_per_hour'
        )"
    );

    if($insert)
    {
        $message = "Court added successfully";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Courts</title>
<link rel="stylesheet" href="../css/style.css">
</head>

<body>

<h2>Manage Courts</h2>

<p>
<?php echo $message; ?>
</p>

<form method="POST">

<label>Court Name</label>
<br>
<input
type="text"
name="court_name">
<br><br>

<label>Court Type</label>
<br>

<select name="court_type">
<option>Badminton</option>
<option>Futsal</option>
<option>Basketball</option>
<option>Tennis</option>
</select>

<br><br>

<label>Description</label>
<br>

<textarea
name="description">
</textarea>

<br><br>

<label>Price Per Hour</label>
<br>

<input
type="number"
step="0.01"
name="price_per_hour">

<br><br>

<button
type="submit"
name="add_court">
Add Court
</button>

</form>

<hr>

<h3>Existing Courts</h3>

<table border="1">

<tr>
<th>ID</th>
<th>Name</th>
<th>Type</th>
<th>Price</th>
</tr>

<?php

$courts = mysqli_query(
$conn,
"SELECT * FROM courts"
);

while($row =
mysqli_fetch_assoc($courts))
{
?>

<tr>

<td>
<?php echo $row['court_id']; ?>
</td>

<td>
<?php echo $row['court_name']; ?>
</td>

<td>
<?php echo $row['court_type']; ?>
</td>

<td>
RM <?php echo $row['price_per_hour']; ?>
</td>

</tr>

<?php
}
?>

</table>

<br>

<a href="dashboard.php">
Back to Dashboard
</a>

</body>
</html>