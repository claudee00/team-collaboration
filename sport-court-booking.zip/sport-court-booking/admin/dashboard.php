<?php
session_start();
include '../config/database.php';
if(!isset($_SESSION['user_id']))
{
    header("Location: ../login.php");
    exit();
}

if($_SESSION['role'] != 'admin')
{
    header("Location: ../login.php");
    exit();
}
$totalCourts =
mysqli_fetch_assoc(
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
FROM courts"
)
);

$totalCustomers =
mysqli_fetch_assoc(
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
FROM users
WHERE role='customer'"
)
);

$totalBookings =
mysqli_fetch_assoc(
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
FROM bookings"
)
);

$totalRevenue =
mysqli_fetch_assoc(
mysqli_query(
$conn,
"SELECT
IFNULL(SUM(amount),0)
AS total
FROM payments
WHERE payment_status='Paid'"
)
);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>

<h1>Admin Dashboard</h1>
<div class="stats-box">

<h3>System Statistics</h3>

<p>
Total Courts:
<strong>
<?php echo $totalCourts['total']; ?>
</strong>
</p>

<p>
Total Customers:
<strong>
<?php echo $totalCustomers['total']; ?>
</strong>
</p>

<p>
Total Bookings:
<strong>
<?php echo $totalBookings['total']; ?>
</strong>
</p>

<p>
Total Revenue:
<strong>
RM <?php echo number_format($totalRevenue['total'],2); ?>
</strong>
</p>

</div>

<p>Welcome,
<?php echo $_SESSION['full_name']; ?>
</p>

<hr>

<div class="menu">

<h3>Menu</h3>

<ul>

<li>
<a href="manage_courts.php">
Manage Courts
</a>
</li>

<li>
<a href="manage_timeslots.php">
Manage Time Slots
</a>
</li>

<li>
<a href="manage_bookings.php">
Manage Bookings
</a>
</li>

<li>
<a href="payment_records.php">
Payment Records
</a>
</li>

<li>
<a href="manage_users.php">
Manage Users
</a>
</li>

<li>
<a href="reports.php">
Reports
</a>
</li>

</ul>

</div>

<hr>

<a href="../logout.php">
Logout
</a>

</body>
</html>