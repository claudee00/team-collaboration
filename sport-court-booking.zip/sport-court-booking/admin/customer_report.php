<?php

session_start();

include '../config/database.php';

?>

<!DOCTYPE html>
<html>

<head>

<title>Customer Report</title>

<link
rel="stylesheet"
href="../css/style.css">

</head>

<body>

<h1>Customer Report</h1>

<button onclick="window.print()">
Print Report
</button>

<br><br>

<table>

<tr>

<th>User ID</th>
<th>Name</th>
<th>Email</th>
<th>Phone</th>
<th>Role</th>

</tr>

<?php

$query =
mysqli_query(
$conn,
"

SELECT *
FROM users

ORDER BY user_id DESC

"
);

while(
$row =
mysqli_fetch_assoc($query)
)
{
?>

<tr>

<td><?php echo $row['user_id']; ?></td>

<td><?php echo $row['full_name']; ?></td>

<td><?php echo $row['email']; ?></td>

<td><?php echo $row['phone_number']; ?></td>

<td><?php echo $row['role']; ?></td>

</tr>

<?php
}
?>

</table>

</body>
</html>