<?php

session_start();

include '../config/database.php';

?>

<!DOCTYPE html>
<html>

<head>

<title>Booking Report</title>

<link
rel="stylesheet"
href="../css/style.css">

</head>

<body>

<h1>Booking Report</h1>

<button onclick="window.print()">
Print Report
</button>

<br><br>

<table>

<tr>

<th>Booking ID</th>
<th>Customer</th>
<th>Court</th>
<th>Date</th>
<th>Status</th>

</tr>

<?php

$query =
mysqli_query(
$conn,
"

SELECT

bookings.booking_id,
users.full_name,
courts.court_name,
timeslots.slot_date,
bookings.booking_status

FROM bookings

JOIN users
ON users.user_id =
bookings.user_id

JOIN timeslots
ON timeslots.timeslot_id =
bookings.timeslot_id

JOIN courts
ON courts.court_id =
timeslots.court_id

ORDER BY bookings.booking_id DESC

"
);

while(
$row =
mysqli_fetch_assoc($query)
)
{
?>

<tr>

<td><?php echo $row['booking_id']; ?></td>

<td><?php echo $row['full_name']; ?></td>

<td><?php echo $row['court_name']; ?></td>

<td><?php echo $row['slot_date']; ?></td>

<td><?php echo $row['booking_status']; ?></td>

</tr>

<?php
}
?>

</table>

</body>
</html>