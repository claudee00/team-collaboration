<?php

session_start();

include '../config/database.php';

if(!isset($_SESSION['user_id']))
{
    header("Location: ../login.php");
    exit();
}

if($_SESSION['role'] != 'admin')
{
    header("Location: ../login.php");
    exit();
}

$totalUsers =
mysqli_fetch_assoc(
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
FROM users"
)
);

$totalCustomers =
mysqli_fetch_assoc(
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
FROM users
WHERE role='customer'"
)
);

$totalAdmins =
mysqli_fetch_assoc(
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
FROM users
WHERE role='admin'"
)
);

$search = "";

if(isset($_GET['search']))
{
    $search = trim($_GET['search']);
}

?>

<!DOCTYPE html>
<html>

<head>

<title>Manage Users</title>

<link
rel="stylesheet"
href="../css/style.css">

</head>

<body>

<h1>Manage Users</h1>

<div class="stats-box">

<h3>User Statistics</h3>

<p>
Total Users:
<strong>
<?php echo $totalUsers['total']; ?>
</strong>
</p>

<p>
Total Customers:
<strong>
<?php echo $totalCustomers['total']; ?>
</strong>
</p>

<p>
Total Admins:
<strong>
<?php echo $totalAdmins['total']; ?>
</strong>
</p>

</div>

<form method="GET">

<input
type="text"
name="search"
placeholder="Search user name"

value="<?php echo $search; ?>">

<button type="submit">
Search
</button>

<a href="manage_users.php">
Reset
</a>

</form>

<table>

<tr>

<th>User ID</th>
<th>Full Name</th>
<th>Email</th>
<th>Phone Number</th>
<th>Role</th>
<th>Created At</th>

</tr>

<?php

$sql = "
SELECT *
FROM users
";

if(!empty($search))
{
    $sql .= "
    WHERE full_name
    LIKE '%$search%'
    ";
}

$sql .= "
ORDER BY user_id DESC
";

$query =
mysqli_query(
$conn,
$sql
);

while(
$row =
mysqli_fetch_assoc($query)
)
{
?>

<tr>

<td>
<?php echo $row['user_id']; ?>
</td>

<td>
<?php echo $row['full_name']; ?>
</td>

<td>
<?php echo $row['email']; ?>
</td>

<td>
<?php echo $row['phone_number']; ?>
</td>

<td>
<?php echo $row['role']; ?>
</td>

<td>
<?php echo $row['created_at']; ?>
</td>

</tr>

<?php
}
?>

</table>

<br>

<a href="dashboard.php">
Back to Dashboard
</a>

</body>
</html>