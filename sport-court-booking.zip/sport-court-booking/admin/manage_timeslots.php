<?php

session_start();

include '../config/database.php';

if(!isset($_SESSION['user_id']))
{
    header("Location: ../login.php");
    exit();
}

if($_SESSION['role'] != 'admin')
{
    header("Location: ../login.php");
    exit();
}

$message = "";

if(isset($_POST['add_slot']))
{
    $court_id = $_POST['court_id'];
    $slot_date = $_POST['slot_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    $insert = mysqli_query(
        $conn,
        "INSERT INTO timeslots
        (
            court_id,
            slot_date,
            start_time,
            end_time
        )
        VALUES
        (
            '$court_id',
            '$slot_date',
            '$start_time',
            '$end_time'
        )"
    );

    if($insert)
    {
        $message = "Time slot added successfully";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Time Slots</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<h2>Manage Time Slots</h2>

<p><?php echo $message; ?></p>

<form method="POST">

<label>Select Court</label>
<br>

<select name="court_id">

<?php

$courts = mysqli_query(
    $conn,
    "SELECT * FROM courts"
);

while($court =
    mysqli_fetch_assoc($courts))
{
?>

<option
value="<?php echo $court['court_id']; ?>">

<?php echo $court['court_name']; ?>

</option>

<?php
}
?>

</select>

<br><br>

<label>Date</label>
<br>
<input
type="date"
name="slot_date"
required>

<br><br>

<label>Start Time</label>
<br>
<input
type="time"
name="start_time"
required>

<br><br>

<label>End Time</label>
<br>
<input
type="time"
name="end_time"
required>

<br><br>

<button
type="submit"
name="add_slot">

Add Time Slot

</button>

</form>

<hr>

<h3>Existing Time Slots</h3>

<table border="1">

<tr>
<th>ID</th>
<th>Court</th>
<th>Date</th>
<th>Start</th>
<th>End</th>
<th>Status</th>
</tr>

<?php

$slots = mysqli_query(
$conn,
"SELECT
timeslots.*,
courts.court_name
FROM timeslots
JOIN courts
ON courts.court_id =
timeslots.court_id"
);

while($row =
mysqli_fetch_assoc($slots))
{
?>

<tr>

<td>
<?php echo $row['timeslot_id']; ?>
</td>

<td>
<?php echo $row['court_name']; ?>
</td>

<td>
<?php echo $row['slot_date']; ?>
</td>

<td>
<?php echo $row['start_time']; ?>
</td>

<td>
<?php echo $row['end_time']; ?>
</td>

<td>
<?php echo $row['availability']; ?>
</td>

</tr>

<?php
}
?>

</table>

<br>

<a href="dashboard.php">
Back to Dashboard
</a>

</body>
</html>