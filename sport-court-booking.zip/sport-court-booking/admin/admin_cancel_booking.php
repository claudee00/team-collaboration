<?php

session_start();

include '../config/database.php';

if($_SESSION['role'] != 'admin')
{
    header("Location: ../login.php");
    exit();
}

$booking_id = $_GET['id'];

$query = mysqli_query(
$conn,
"SELECT * FROM bookings
WHERE booking_id='$booking_id'"
);

$booking =
mysqli_fetch_assoc($query);

if(!$booking)
{
    die("Booking not found");
}

$paymentCheck =
mysqli_query(
$conn,
"SELECT *
FROM payments
WHERE booking_id='$booking_id'
AND payment_status='Paid'"
);

if(mysqli_num_rows($paymentCheck) > 0)
{
    die("Paid bookings cannot be cancelled.");
}

mysqli_query(
$conn,
"UPDATE bookings
SET booking_status='Cancelled'
WHERE booking_id='$booking_id'"
);

mysqli_query(
$conn,
"UPDATE timeslots
SET availability='Available'
WHERE timeslot_id='{$booking['timeslot_id']}'"
);

header(
"Location: manage_bookings.php"
);

exit();

?>