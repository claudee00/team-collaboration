<?php

session_start();

include '../config/database.php';

if(!isset($_SESSION['user_id']))
{
    header("Location: ../login.php");
    exit();
}

if($_SESSION['role'] != 'admin')
{
    header("Location: ../login.php");
    exit();
}

$search = "";

if(isset($_GET['search']))
{
    $search = trim($_GET['search']);
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Bookings</title>
<link rel="stylesheet" href="../css/style.css">
</head>

<body>

<h2>Manage Bookings</h2>

<form method="GET">

<input
type="text"
name="search"
placeholder="Search customer or court"
value="<?php echo $search; ?>">

<button type="submit">
Search
</button>

<a href="manage_bookings.php">
Reset
</a>

</form>

<br>

<table border="1">

<tr>
<th>Booking ID</th>
<th>Customer</th>
<th>Court</th>
<th>Date</th>
<th>Time</th>
<th>Amount</th>
<th>Status</th>
<th>Payment Status</th>
<th>Action</th>
</tr>

<?php

$sql = "
SELECT
bookings.*,
users.full_name,
courts.court_name,
timeslots.slot_date,
timeslots.start_time,
timeslots.end_time,
payments.payment_status

FROM bookings

JOIN users
ON users.user_id =
bookings.user_id

JOIN timeslots
ON timeslots.timeslot_id =
bookings.timeslot_id

JOIN courts
ON courts.court_id =
timeslots.court_id

LEFT JOIN payments
ON payments.booking_id =
bookings.booking_id
";

if(!empty($search))
{
    $sql .= "
    WHERE
    users.full_name LIKE '%$search%'
    OR
    courts.court_name LIKE '%$search%'
    ";
}

$sql .= "
ORDER BY bookings.booking_id DESC
";

$query = mysqli_query(
$conn,
$sql
);

while($row =
mysqli_fetch_assoc($query))
{
?>

<tr>

<td>
<?php echo $row['booking_id']; ?>
</td>

<td>
<?php echo $row['full_name']; ?>
</td>

<td>
<?php echo $row['court_name']; ?>
</td>

<td>
<?php echo $row['slot_date']; ?>
</td>

<td>
<?php echo $row['start_time']; ?>
-
<?php echo $row['end_time']; ?>
</td>

<td>
RM <?php echo $row['total_amount']; ?>
</td>

<td>
<?php echo $row['booking_status']; ?>
</td>

<td>

<?php

if($row['payment_status'] == 'Paid')
{
    echo "Paid";
}
else
{
    echo "Unpaid";
}

?>

</td>

<td>

<?php
if($row['booking_status'] == 'Cancelled')
{
    echo "-";
}
elseif($row['payment_status'] == 'Paid')
{
    echo "Paid Booking";
}
else
{
?>

<a href="admin_cancel_booking.php?id=<?php echo $row['booking_id']; ?>">
Cancel
</a>

<?php
}
?>

</td>

</tr>

<?php
}
?>

</table>

<br>

<a href="dashboard.php">
Back to Dashboard
</a>

</body>
</html>