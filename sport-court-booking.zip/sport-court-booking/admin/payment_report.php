<?php

session_start();

include '../config/database.php';

?>

<!DOCTYPE html>
<html>

<head>

<title>Payment Report</title>

<link
rel="stylesheet"
href="../css/style.css">

</head>

<body>

<h1>Payment Report</h1>

<button onclick="window.print()">
Print Report
</button>

<br><br> 

<table>

<tr>

<th>Payment ID</th>
<th>Customer</th>
<th>Amount</th>
<th>Method</th>
<th>Date</th>

</tr>

<?php

$query =
mysqli_query(
$conn,
"

SELECT

payments.payment_id,
users.full_name,
payments.amount,
payments.payment_method,
payments.payment_date

FROM payments

JOIN bookings
ON bookings.booking_id =
payments.booking_id

JOIN users
ON users.user_id =
bookings.user_id

ORDER BY payments.payment_id DESC

"
);

while(
$row =
mysqli_fetch_assoc($query)
)
{
?>

<tr>

<td><?php echo $row['payment_id']; ?></td>

<td><?php echo $row['full_name']; ?></td>

<td>RM <?php echo $row['amount']; ?></td>

<td><?php echo $row['payment_method']; ?></td>

<td><?php echo $row['payment_date']; ?></td>

</tr>

<?php
}
?>

</table>

</body>
</html>