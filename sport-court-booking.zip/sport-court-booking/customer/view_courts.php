<?php

session_start();

include '../config/database.php';

if(!isset($_SESSION['user_id']))
{
    header("Location: ../login.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>View Courts</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>

<h2>Available Courts & Time Slots</h2>

<table border="1">

<tr>
    <th>Court Name</th>
    <th>Type</th>
    <th>Price Per Hour</th>
    <th>Date</th>
    <th>Start Time</th>
    <th>End Time</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php

$query = mysqli_query(
$conn,
"SELECT
timeslots.timeslot_id,
courts.court_name,
courts.court_type,
courts.price_per_hour,
timeslots.slot_date,
timeslots.start_time,
timeslots.end_time,
timeslots.availability

FROM timeslots

JOIN courts
ON courts.court_id =
timeslots.court_id

WHERE timeslots.availability = 'Available'

ORDER BY timeslots.slot_date ASC,
timeslots.start_time ASC"
);

while($row =
mysqli_fetch_assoc($query))
{
?>

<tr>

<td>
<?php echo $row['court_name']; ?>
</td>

<td>
<?php echo $row['court_type']; ?>
</td>

<td>
RM <?php echo $row['price_per_hour']; ?>
</td>

<td>
<?php echo $row['slot_date']; ?>
</td>

<td>
<?php echo $row['start_time']; ?>
</td>

<td>
<?php echo $row['end_time']; ?>
</td>

<td>
<?php echo $row['availability']; ?>
</td>

<td>

<?php
if($row['availability'] == 'Available')
{
?>

<a href="book_court.php?id=<?php echo $row['timeslot_id']; ?>">
Book
</a>

<?php
}
else
{
    echo "-";
}
?>

</td>

</tr>

<?php
}
?>

</table>

<br>

<a href="dashboard.php">
Back to Dashboard
</a>

</body>
</html>