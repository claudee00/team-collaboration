<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
<title>Booking Success</title>
<link rel="stylesheet" href="../css/style.css">
</head>

<body>

<h2>
Booking Successful!
</h2>

<p>
Your court booking has been confirmed.
</p>

<a href="dashboard.php">
Return to Dashboard
</a>

</body>
</html>