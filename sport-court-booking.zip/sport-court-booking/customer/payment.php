<?php

session_start();

include '../config/database.php';

$booking_id = $_GET['id'];

$query = mysqli_query(
$conn,
"SELECT *
FROM bookings
WHERE booking_id='$booking_id'"
);

$booking =
mysqli_fetch_assoc($query);

if(!$booking)
{
    die("Booking not found");
}

$existingPayment =
mysqli_query(
$conn,
"SELECT *
FROM payments
WHERE booking_id='$booking_id'
AND payment_status='Paid'"
);

if(mysqli_num_rows($existingPayment) > 0)
{
    die("This booking has already been paid.");
}

if($booking['booking_status'] == 'Cancelled')
{
    die("Cannot make payment for a cancelled booking.");
}

if(isset($_POST['pay']))
{
    $payment_method =
    $_POST['payment_method'];

    mysqli_query(
    $conn,
    "INSERT INTO payments
    (
        booking_id,
        amount,
        payment_method,
        payment_status,
        payment_date
    )
    VALUES
    (
        '$booking_id',
        '{$booking['total_amount']}',
        '$payment_method',
        'Paid',
        NOW()
    )"
    );

    header(
    "Location: receipt.php?id=$booking_id"
    );

    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Payment</title>
<link rel="stylesheet" href="../css/style.css">
</head>

<body>

<h2>Payment</h2>

<p>
Booking ID:
<?php echo $booking_id; ?>
</p>

<p>
Amount:
RM <?php echo $booking['total_amount']; ?>
</p>

<form method="POST">

<label>
Payment Method
</label>

<br>

<select
name="payment_method">

<option>
FPX
</option>

<option>
Credit Card
</option>

<option>
Debit Card
</option>

<option>
E-Wallet
</option>

</select>

<br><br>

<button
type="submit"
name="pay">

Pay Now

</button>

</form>

</body>
</html>