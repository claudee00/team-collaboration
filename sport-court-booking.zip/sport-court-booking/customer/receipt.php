<?php

session_start();

include '../config/database.php';

$booking_id = $_GET['id'];

$query = mysqli_query(
$conn,
"SELECT
bookings.*,
payments.payment_method,
payments.payment_date,
courts.court_name,
timeslots.slot_date,
timeslots.start_time,
timeslots.end_time

FROM bookings

JOIN payments
ON payments.booking_id =
bookings.booking_id

JOIN timeslots
ON timeslots.timeslot_id =
bookings.timeslot_id

JOIN courts
ON courts.court_id =
timeslots.court_id

WHERE bookings.booking_id =
'$booking_id'

ORDER BY payments.payment_id DESC
LIMIT 1"
);

$data =
mysqli_fetch_assoc($query);

?>

<!DOCTYPE html>
<html>
<head>
<title>Receipt</title>
<link rel="stylesheet" href="../css/style.css">
</head>

<body>

<h1>
SPORT COURT BOOKING RECEIPT
</h1>

<hr>

<p>
Booking ID:
<?php echo $data['booking_id']; ?>
</p>

<p>
Court:
<?php echo $data['court_name']; ?>
</p>

<p>
Date:
<?php echo $data['slot_date']; ?>
</p>

<p>
Time:
<?php echo $data['start_time']; ?>
-
<?php echo $data['end_time']; ?>
</p>

<p>
Amount:
RM <?php echo $data['total_amount']; ?>
</p>

<p>
Payment Method:
<?php echo $data['payment_method']; ?>
</p>

<p>
Payment Date:
<?php echo $data['payment_date']; ?>
</p>

<hr>

<h3>
Payment Successful
</h3>

<a href="my_bookings.php">
Back to My Bookings
</a>

</body>
</html>