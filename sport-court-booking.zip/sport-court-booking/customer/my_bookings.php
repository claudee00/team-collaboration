<?php

session_start();

include '../config/database.php';

if(!isset($_SESSION['user_id']))
{
    header("Location: ../login.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
<title>My Bookings</title>
<link rel="stylesheet" href="../css/style.css">
</head>

<body>

<h2>My Bookings</h2>

<table border="1">

<tr>
<th>Booking ID</th>
<th>Court</th>
<th>Date</th>
<th>Start</th>
<th>End</th>
<th>Amount</th>
<th>Booking Status</th>
<th>Payment Status</th>
<th>Payment</th>
<th>Action</th>
</tr>

<?php

$query = mysqli_query(
$conn,
"SELECT
bookings.*,
courts.court_name,
timeslots.slot_date,
timeslots.start_time,
timeslots.end_time,
payments.payment_status

FROM bookings

JOIN timeslots
ON bookings.timeslot_id =
timeslots.timeslot_id

JOIN courts
ON courts.court_id =
timeslots.court_id

LEFT JOIN payments
ON payments.booking_id =
bookings.booking_id

WHERE bookings.user_id =
'{$_SESSION['user_id']}'"
);

while($row =
mysqli_fetch_assoc($query))
{
?>

<tr>

<td><?php echo $row['booking_id']; ?></td>

<td><?php echo $row['court_name']; ?></td>

<td><?php echo $row['slot_date']; ?></td>

<td><?php echo $row['start_time']; ?></td>

<td><?php echo $row['end_time']; ?></td>

<td>RM <?php echo $row['total_amount']; ?></td>

<td><?php echo $row['booking_status']; ?></td>

<td>

<?php

if($row['payment_status'] == 'Paid')
{
    echo "🟢 Paid";
}
else
{
    echo "🔴 Unpaid";
}

?>

</td>

<td>

<?php

if($row['booking_status'] == 'Cancelled')
{
    echo "-";
}
elseif($row['payment_status'] == 'Paid')
{
    echo "Paid";
}
else
{
?>

<a href="payment.php?id=<?php echo $row['booking_id']; ?>">
Pay Now
</a>

<?php
}
?>

</td>

<td>

<?php
if($row['booking_status'] == 'Cancelled')
{
    echo "-";
}
elseif($row['payment_status'] == 'Paid')
{
    echo "Cannot Cancel";
}
else
{
?>

<a href="cancel_booking.php?id=<?php echo $row['booking_id']; ?>">
Cancel
</a>

<?php
}
?>

</td>

</tr>

<?php
}
?>

</table>

<br>

<a href="dashboard.php">
Back to Dashboard
</a>

</body>
</html>