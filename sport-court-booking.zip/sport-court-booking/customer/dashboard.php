<?php
session_start();
include '../config/database.php';
if(!isset($_SESSION['user_id']))
{
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$myBookings =
mysqli_fetch_assoc(
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
FROM bookings
WHERE user_id='$user_id'"
)
);

$myPaidBookings =
mysqli_fetch_assoc(
mysqli_query(
$conn,
"SELECT COUNT(*) AS total

FROM bookings

JOIN payments
ON payments.booking_id =
bookings.booking_id

WHERE bookings.user_id='$user_id'
AND payments.payment_status='Paid'"
)
);

$myActiveBookings =
mysqli_fetch_assoc(
mysqli_query(
$conn,
"SELECT COUNT(*) AS total

FROM bookings

WHERE user_id='$user_id'
AND booking_status='Confirmed'"
)
);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Customer Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<h1>Customer Dashboard</h1>

<div class="stats-box">

<h3>My Statistics</h3>

<p>
My Bookings:
<strong>
<?php echo $myBookings['total']; ?>
</strong>
</p>

<p>
Paid Bookings:
<strong>
<?php echo $myPaidBookings['total']; ?>
</strong>
</p>

<p>
Active Bookings:
<strong>
<?php echo $myActiveBookings['total']; ?>
</strong>
</p>

</div>

<p>
Welcome,
<?php echo $_SESSION['full_name']; ?>
</p>

<hr>

<div class="menu">

<h3>Menu</h3>

<ul>

<li>
<a href="view_courts.php">
View Courts & Availability
</a>
</li>

<li>
<a href="my_bookings.php">
My Bookings
</a>
</li>

</ul>

</div>

<hr>

<a href="../logout.php">
Logout
</a>

</body>
</html>