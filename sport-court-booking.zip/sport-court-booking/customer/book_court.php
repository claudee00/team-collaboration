<?php

session_start();

include '../config/database.php';

if(!isset($_SESSION['user_id']))
{
    header("Location: ../login.php");
    exit();
}

$timeslot_id = $_GET['id'];

$query = mysqli_query(
$conn,
"SELECT
timeslots.*,
courts.court_name,
courts.price_per_hour

FROM timeslots

JOIN courts
ON courts.court_id =
timeslots.court_id

WHERE timeslots.timeslot_id =
'$timeslot_id'"
);

$slot = mysqli_fetch_assoc($query);

if(!$slot)
{
    die("Invalid time slot");
}

if($slot['availability'] != 'Available')
{
    die("This slot is not available");
}

$total_amount =
$slot['price_per_hour'];

if(isset($_POST['confirm_booking']))
{
    $checkSlot =
    mysqli_query(
    $conn,
    "SELECT *
    FROM timeslots
    WHERE timeslot_id='$timeslot_id'
    AND availability='Available'"
    );

    if(mysqli_num_rows($checkSlot) == 0)
    {
        die("Sorry. This slot has already been booked.");
    }

    mysqli_query(
    $conn,
    "INSERT INTO bookings
    (
        user_id,
        timeslot_id,
        booking_status,
        total_amount
    )
    VALUES
    (
        '{$_SESSION['user_id']}',
        '$timeslot_id',
        'Confirmed',
        '$total_amount'
    )"
    );

    mysqli_query(
    $conn,
    "UPDATE timeslots
    SET availability='Booked'
    WHERE timeslot_id='$timeslot_id'"
    );

    header(
    "Location: booking_success.php"
    );

    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Book Court</title>
<link rel="stylesheet" href="../css/style.css">
</head>

<body>

<h2>Booking Confirmation</h2>

<p>
Court:
<?php echo $slot['court_name']; ?>
</p>

<p>
Date:
<?php echo $slot['slot_date']; ?>
</p>

<p>
Start:
<?php echo $slot['start_time']; ?>
</p>

<p>
End:
<?php echo $slot['end_time']; ?>
</p>

<p>
Amount:
RM <?php echo $total_amount; ?>
</p>

<form method="POST">

<button
type="submit"
name="confirm_booking">

Confirm Booking

</button>

</form>

</body>
</html>