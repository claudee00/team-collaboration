<?php

include 'config/database.php';

$message = "";

if(isset($_POST['register']))
{
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone_number = trim($_POST['phone_number']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validation 1
    if(
        empty($full_name) ||
        empty($email) ||
        empty($phone_number) ||
        empty($password) ||
        empty($confirm_password)
    )
    {
        $message = "Please fill in all required fields";
    }

    // Validation 2
    elseif($password != $confirm_password)
    {
        $message = "Passwords do not match";
    }

    else
    {
        // Check email
        $check_email = mysqli_query(
            $conn,
            "SELECT * FROM users WHERE email='$email'"
        );

        if(mysqli_num_rows($check_email) > 0)
        {
            $message = "This email is already registered";
        }
        else
        {
            $hashed_password =
                password_hash($password, PASSWORD_DEFAULT);

            $insert = mysqli_query(
                $conn,
                "INSERT INTO users
                (
                    full_name,
                    email,
                    phone_number,
                    password
                )
                VALUES
                (
                    '$full_name',
                    '$email',
                    '$phone_number',
                    '$hashed_password'
                )"
            );

            if($insert)
            {
                $message =
                "Account registered successfully!";
            }
            else
            {
                $message =
                "Registration failed.";
            }
        }
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Register Account</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="container">

<div class="card">

<h2>Register Account</h2>

<p style="color:red;">
    <?php echo $message; ?>
</p>

<form method="POST">

    <label>Full Name</label>
    <br>
    <input
        type="text"
        name="full_name"
    >
    <br><br>

    <label>Email</label>
    <br>
    <input
        type="email"
        name="email"
    >
    <br><br>

    <label>Phone Number</label>
    <br>
    <input
        type="text"
        name="phone_number"
    >
    <br><br>

    <label>Password</label>
    <br>
    <input
        type="password"
        name="password"
    >
    <br><br>

    <label>Confirm Password</label>
    <br>
    <input
        type="password"
        name="confirm_password"
    >
    <br><br>

    <button
        type="submit"
        name="register"
    >
        Register
    </button>

</form>

<br>

<a href="login.php">
    Go to Login
</a>

</div>
</div>

</body>
</html>