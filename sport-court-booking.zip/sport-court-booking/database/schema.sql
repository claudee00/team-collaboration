CREATE DATABASE IF NOT EXISTS sport_court_booking;
USE sport_court_booking;

-- USERS
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone_number VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    role ENUM('customer','admin') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- COURTS
CREATE TABLE courts (
    court_id INT AUTO_INCREMENT PRIMARY KEY,
    court_name VARCHAR(100) NOT NULL,
    court_type ENUM('Badminton','Futsal','Basketball','Tennis') NOT NULL,
    description TEXT,
    price_per_hour DECIMAL(10,2) NOT NULL,
    status ENUM('Active','Inactive') DEFAULT 'Active'
);

-- TIME SLOTS
CREATE TABLE timeslots (
    timeslot_id INT AUTO_INCREMENT PRIMARY KEY,
    court_id INT NOT NULL,
    slot_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    availability ENUM('Available','Booked','Blocked')
        DEFAULT 'Available',

    FOREIGN KEY (court_id)
        REFERENCES courts(court_id)
        ON DELETE CASCADE
);

-- BOOKINGS
CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,

    user_id INT NOT NULL,
    timeslot_id INT NOT NULL,

    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    booking_status ENUM(
        'Pending',
        'Confirmed',
        'Cancelled'
    ) DEFAULT 'Pending',

    total_amount DECIMAL(10,2),

    FOREIGN KEY (user_id)
        REFERENCES users(user_id),

    FOREIGN KEY (timeslot_id)
        REFERENCES timeslots(timeslot_id)
);

-- PAYMENTS
CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,

    booking_id INT NOT NULL,

    amount DECIMAL(10,2) NOT NULL,

    payment_method ENUM(
        'FPX',
        'Credit Card',
        'Debit Card',
        'E-Wallet'
    ),

    payment_status ENUM(
        'Paid',
        'Unpaid'
    ) DEFAULT 'Unpaid',

    payment_date TIMESTAMP NULL,

    FOREIGN KEY (booking_id)
        REFERENCES bookings(booking_id)
);

INSERT INTO users
(
full_name,
email,
phone_number,
password,
role
)
VALUES
(
'System Admin',
'admin@sportcourt.com',
'0123456789',
'$2y$10$kT6lmW7P6nGjZb4n1y6z6O2RmK2xE4H4Q6s4O7Gm2o6u4i9xg6xKm',
'admin'
);