<?php

session_start();

include 'config/database.php';

$message = "";

if(isset($_POST['login']))
{
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if(empty($email) || empty($password))
    {
        $message = "Please fill in all required fields";
    }
    else
    {
        $query = mysqli_query(
            $conn,
            "SELECT * FROM users
             WHERE email='$email'"
        );

        if(mysqli_num_rows($query) == 1)
        {
            $user = mysqli_fetch_assoc($query);

            if(password_verify(
                $password,
                $user['password']
            ))
            {
                $_SESSION['user_id']
                    = $user['user_id'];

                $_SESSION['full_name']
                    = $user['full_name'];

                $_SESSION['role']
                    = $user['role'];

                if($user['role'] == 'admin')
                {
                    header(
                    "Location: admin/dashboard.php"
                    );
                }
                else
                {
                    header(
                    "Location: customer/dashboard.php"
                    );
                }

                exit();
            }
            else
            {
                $message =
                "Incorrect email or password";
            }
        }
        else
        {
            $message =
            "Incorrect email or password";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="container">

<div class="card">

<h2>Login</h2>

<p style="color:red;">
<?php echo $message; ?>
</p>

<form method="POST">

<label>Email</label>
<br>

<input
type="email"
name="email">

<br><br>

<label>Password</label>
<br>

<input
type="password"
name="password">

<br><br>

<button
type="submit"
name="login">
Login
</button>

</form>

<br>

<a href="register.php">
Register Account
</a>
</div>
</div>
</body>
</html>